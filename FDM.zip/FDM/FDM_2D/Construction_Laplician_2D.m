function Mat = Construction_Laplician_2D(nx, ny, dx, dy)

n = nx * ny;

Mat = sparse(n, n);

coex = 1.0 / dx^2;
coey = 1.0 / dy^2;

%% the index first go along x-direction, and the along y-direction
iy = 1;
iyy = (iy-1)*nx;
ix = 1;
Tem_Mat = sparse(ny, nx);
Tem_Mat(iy, ix) = -2*coey - 2*coex;
Tem_Mat(iy+1, ix) = coey;
Tem_Mat(ny, ix) = coey;
Tem_Mat(iy, ix+1) = coex;
Tem_Mat(iy, nx) = coex;
vec = reshape(Tem_Mat.', [], 1);
Mat(iyy + ix, :) = vec;

parfor ix = 2 : nx-1
    Tem_Mat = sparse(ny, nx);
    Tem_Mat(iy, ix) = -2*coey - 2*coex;
    Tem_Mat(iy+1, ix) = coey;
    Tem_Mat(ny, ix) = coey;
    Tem_Mat(iy, ix+1) = coex;
    Tem_Mat(iy, ix-1) = coex;
    vec = reshape(Tem_Mat.', [], 1);
    Mat(iyy + ix, :) = vec;
end

ix = nx;
Tem_Mat = sparse(ny, nx);
Tem_Mat(iy, ix) = -2*coey - 2*coex;
Tem_Mat(iy+1, ix) = coey;
Tem_Mat(ny, ix) = coey;
Tem_Mat(iy, 1) = coex;
Tem_Mat(iy, ix-1) = coex;
vec = reshape(Tem_Mat.', [], 1);
Mat(iyy + ix, :) = vec;

for iy = 2 : ny-1
    iyy = (iy-1)*nx;
    ix = 1;
    Tem_Mat = sparse(ny, nx);
    Tem_Mat(iy, ix) = -2*coey - 2*coex;
    Tem_Mat(iy+1, ix) = coey;
    Tem_Mat(iy-1, ix) = coex;
    Tem_Mat(iy, ix+1) = coey;
    Tem_Mat(iy, nx) = coex;
    vec = reshape(Tem_Mat.', [], 1);
    Mat(iyy + ix, :) = vec;

    parfor ix = 2 : nx-1
        Tem_Mat = sparse(ny, nx);
        Tem_Mat(iy, ix) = -2*coey - 2*coex;
        Tem_Mat(iy+1, ix) = coey;
        Tem_Mat(iy-1, ix) = coex;
        Tem_Mat(iy, ix+1) = coey;
        Tem_Mat(iy, ix-1) = coex;
        vec = reshape(Tem_Mat.', [], 1);
        Mat(iyy + ix, :) = vec;
    end

    ix = nx;
    Tem_Mat = sparse(ny, nx);
    Tem_Mat(iy, ix) = -2*coey - 2*coex;
    Tem_Mat(iy+1, ix) = coey;
    Tem_Mat(iy-1, ix) = coex;
    Tem_Mat(iy, 1) = coey;
    Tem_Mat(iy, ix-1) = coex;
    vec = reshape(Tem_Mat.', [], 1);
    Mat(iyy + ix, :) = vec;
end

iy = ny;
iyy = (iy-1)*nx;
ix = 1;
Tem_Mat = sparse(ny, nx);
Tem_Mat(iy, ix) = -2*coey - 2*coex;
Tem_Mat(1, ix) = coey;
Tem_Mat(iy-1, ix) = coex;
Tem_Mat(iy, ix+1) = coey;
Tem_Mat(iy, nx) = coex;
vec = reshape(Tem_Mat.', [], 1);
Mat(iyy + ix, :) = vec;

parfor ix = 2 : nx-1
    Tem_Mat = sparse(ny, nx);
    Tem_Mat(iy, ix) = -2*coey - 2*coex;
    Tem_Mat(1, ix) = coey;
    Tem_Mat(iy-1, ix) = coex;
    Tem_Mat(iy, ix+1) = coey;
    Tem_Mat(iy, ix-1) = coex;
    vec = reshape(Tem_Mat.', [], 1);
    Mat(iyy + ix, :) = vec;
end

ix = nx;
Tem_Mat = sparse(ny, nx);
Tem_Mat(iy, ix) = -2*coey - 2*coex;
Tem_Mat(1, ix) = coey;
Tem_Mat(iy-1, ix) = coex;
Tem_Mat(iy, 1) = coey;
Tem_Mat(iy, ix-1) = coex;
vec = reshape(Tem_Mat.', [], 1);
Mat(iyy + ix, :) = vec;

end