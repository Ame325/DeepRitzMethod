function uh = solver_Cahn_Hilliard_full_one_step(u0, left_Mat, rhs_const_Mat)

%rhs = u0 + rhs_const_Mat*((u0.^2 - 3).*u0);
rhs = u0 + rhs_const_Mat*(u0.^3 - 3*u0);
uh = left_Mat \ rhs;

end