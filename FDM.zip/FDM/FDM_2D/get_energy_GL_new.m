function F = get_energy_GL_new(phi, eps2, dx, dy, nx, ny)
    
    Phi = 0.25*(phi.^2-1).^2.0;
    
 % transform the vector phi to matrix form z1
 k=1;
 for j=1:ny
     for i=1:nx
         z1(i,j) = phi(k);
         k = k+1;
     end
 end 
% figure; imagesc(z1)
% pause
 %z1 = phi';
 
 F = 0; k = 0;
    for j=1:ny
        for i=1:nx
            iR = i+1;
            iL = i-1;
            jR = j+1;
            jL = j-1;
            if(iR>nx) 
                iR = iR-nx;
            end
            if(iL<1) 
                iL = iL+nx;
            end
            if(jR>ny) 
                jR = jR-ny;
            end
            if(jL<1) 
                jL = jL+ny;
            end 
            k = k+1;
            hx=(z1(iR,j)-z1(iL,j))/(2*dx);
            hy=(z1(i,jR)-z1(i,jL))/(2*dy);
            F = F + 0.5*eps2*(hx*hx+hy*hy) + Phi(k);
        end
    end
    % F = F*dx*dy/V;
     F = F*dx*dy;

end