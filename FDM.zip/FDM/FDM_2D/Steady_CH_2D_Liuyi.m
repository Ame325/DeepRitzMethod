% Full order scheme for the steady state of 2D CH eq.
% Initial mass = 0.02
% kappa =0.01:
% This code is used to make comparison with Deep Ritz method results.
% Compare with Liuyi Results.
% 
% Three metastable states are obtained in total:
% Lamella phase, circle phase(1 inner, -1 outer; or reverse)
% all the data are stored in the .mat file as follows:
% Circle2_kpa_001_mass002_Nx_Ny_201_dt_001.mat
% Circle1_kpa_001_mass002_Nx_Ny_200_dt_001.mat
% Lamella_kpa_001_mass002_Nx_Ny_201_dt_01.mat

% Various dt and iteration # are used for above 3 cases.


clc
clear
format long

Lx = 1.0;
Ly = 1.0;   % computational domain [0, Lx] X [0, Ly]

nx = 201;
ny = 201;

dx = Lx/nx;
dy = Ly/ny;

V = Ly*Lx; % The area of the domain.

x_all = linspace(0,1,nx+1);
y_all = linspace(0,1,ny+1);

x = x_all(1:nx);
y = y_all(1:ny);
y = y';

n = nx*ny;

[X, Y] = meshgrid(x,y);

dt = 0.1;
m = 0.02;

kappa = 0.01; % mobility parameter in the energy
kpa2 = kappa*kappa;

%% construct the matrix of discretized Laplician
% operator, where the perodical boundary condition is adopted
Mat_Lap = Construction_Laplician_2D(nx, ny, dx, dy);
I = speye(n, n);

% Initialization 1st, converge to phase seperation like state.
% u_init = 0.5 + 0.01*sin(2*pi*x).*cos(2*pi*y); % initial to get circle.
%   u_init = 0.5 + cos(3*pi*x).*cos(3*pi*y); % initial to get circle(in the center).
%  u_init = 0.6 + 0.25*sin(pi*x).*cos(pi*4*y);
% u_init = 0.5; % initial to circle
%pause

% % % 2nd initialization, converge to circle (four corner).
% x0 = 0.5; y0 = 0.5; R = 0.05; epsilon = 0.05;
% r = sqrt((X-x0).^2 + (Y-y0).^2);
% u_init = tanh((R - r) / (sqrt(2)*epsilon));

 % 3rd initial, converge to circle(four corner).
% 随机分布多个圆形核 多相区域的粗化过程。
% n_bubbles = 2;
% xk = [0.2,0.7]; yk = [0.2,0.7]; Rk = [0.1,0.1];
% u_init = -ones(N,N);  % 背景相
% for k = 1:n_bubbles
%     r = sqrt((X-xk(k)).^2 + (Y-yk(k)).^2);
%     u_init(r < Rk(k)) = 1;  % 核内为另一相
% end

% 4th initial (u=1 in Omega), converge to lamella phase
% 平行条纹(kpa=0.05) 研究界面稳定性（如 Rayleigh–Taylor 不稳定性模拟）
 wavelength = 0.15; % 
 u_init = sin(2*pi*X / wavelength);

%load case3-lamella.mat  % His data is stored as line first, column second.
% load case2-circle02.mat
% u_init = data(1:end-1,1:end-1);

U0(1:n,1) = reshape(u_init', [], 1);

mass0 = (sum(U0(2:n-1))+0.5*U0(1)+0.5*U0(n))*dx*dy;
if(abs(mass0-m)>1e-5)
    %U0 = 0.6*U0/mass0; % This trick is not suitable for mass0=0.
    U0 = m/V + U0*V -mass0*V; % Note: This is only suit for domain[0,1]*[0,1].
else
    U0 = U0;
end

mass(1) = (sum(U0(2:n-1))+0.5*U0(1)+0.5*U0(n))*dx*dy;
egy(1) = get_energy_GL_new(U0, kpa2, dx, dy, nx, ny);

%u(:, nt) = U0;

%% the matrices for the Cahn-Hilliard equation
left_Mat = I + kappa^2*dt*Mat_Lap*Mat_Lap - 2*dt*Mat_Lap;
rhs_const_Mat = dt*Mat_Lap;

U1 = U0;

i = 1;

% method 1 to get force, right!
force_vec_L2 = -kpa2*Mat_Lap*U1 + U1.^3.0 - U1;
force_H_1 = -Mat_Lap*force_vec_L2;
% w = minus_Lap_inv_PBC(force_H_1,n,dx*dy);
% force(1) = sqrt(dot(w,force_H_1)*dx*dy);

%force(1) = sqrt(dot(force_vec_H1,force_vec_H1)*dx*dy); % L2 norm, wrong
%force(1) = sqrt(dot(force_H_1,force_vec_L2)*dx*dy); % H^{-1} norm, wrong

% another method to calculate force, right!!!
norm_grad_F_H(1) = gradF_H_PBC(Mat_Lap,U1,kappa,dx*dy,n);     % in H^{-1} metric, right!!
% disp(force(1))
% disp(norm_grad_F_H(1))
% pause

norm_dst(1) = 1.0;
tic
%for t = dt : dt : T
% while i<2000 % 
while norm_grad_F_H(i)>1e-7 & i<3000
%while force(i)>4.49e-7 & i<2000 % kappa = 0.05  % initial 1

    i = i+1; 

    U1 = solver_Cahn_Hilliard_full_one_step(U0, left_Mat, rhs_const_Mat);

    force_L2 = -kappa^2.0*Mat_Lap*U1 + U1.^3.0 - U1;
    force_H_1 = -Mat_Lap*force_L2;
   
    % w = minus_Lap_inv_PBC(force_H_1,n,dx);
    % force(nt) = sqrt(dot(w,force_H_1)*dx*dy);
    %force(i+1) = sqrt(dot(force_H_1,force_H_1)*dx*dy); % L2 norm, wrong
    %force(i+1) = sqrt(dot(force_H_1,force_L2)*dx*dy); % H^{-1} norm, wrong

    norm_grad_F_H(i) = gradF_H_PBC(Mat_Lap,U1,kappa,dx*dy,n);     % in H^{-1} metric, yes

    norm_dist(i) = sqrt(dot(U1-U0,U1-U0)*dx*dy);
   
    mass(i) = (sum(U1(2:n-1))+0.5*U1(1)+0.5*U1(n))*dx*dy;

    U1 = 0.02/V + U1*V - mass(i)*V;  % ensure mass is 0.02.

    egy(i) = get_energy_GL_new(U1, kpa2, dx, dy, nx, ny);

     U0 = U1;

     fprintf(' % 6i  |', i)
     fprintf(' %18.12f |  %18.12f  |  %18.12f | \n ', norm_dist(i), norm_grad_F_H(i), egy(i) )

    %u(:, nt) = U0;

end
time_full = toc

%uh_full = reshape(u(:, nt-1), [nx, ny]);
uh_full = reshape(U1, [nx, ny]);

% periodic boundary condition
uh_full(:,ny+1) = uh_full(:,1);
uh_full(nx+1,:) = uh_full(1,:);

figure; plot((norm_grad_F_H(1:end)))
title('force')
figure; plot(log(norm_dist(2:end)))
title('norm dist')
figure; plot(egy)
title('energy')
figure; plot(mass)
title('mass')

figure;
imagesc(x_all,y_all,uh_full)
colorbar;
clim([-1, 1]);
set(gca, 'YDir', 'normal')
colormap('jet')
%mesh(x, y, uh_full, uh_full)

% Check mass conservation during the process.

% save('CH_2D_steady1_N200_kpa_005.mat')
% save('CH_kpa001_N200_t_enough.mat')
% save('CH_kpa001_N128_t_enough.mat')
% save('CH_2D_steady1_N128_kpa_001.mat','U1')

%save('CH_2D_steady_circle_N201_kpa005_mass_05.mat','U1')
%save('CH_2D_steady_lamella_N201_kpa005_mass_05.mat','U1')
% U1 now is still 200*200, with the unique difference that uh_full(201,201)
% The impact reflects in plotting.

% save 

