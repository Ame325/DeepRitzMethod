
function L_phi = L_CH_PBC(phi, phi_k, v, w, kpa, dx, N)
        % Copied from L_CH_NBC_new.m
        % This code is right! L decrease with time
       
        % define phi_tilte
        phi_tilte = phi_k + dot(w,phi-phi_k)*dx*v;     % contain N elements
        
        % get phi_tilte_x
        for i=1:N
            if (i==N)
                phi_tilte(i+1) = phi_tilte(1);
            end
            phi_tilte_x(i) = (phi_tilte(i+1)-phi_tilte(i))/dx;
        end
        phi_tilte_x = phi_tilte_x';
            
        % get phi_x
       for i=1:N
            if (i==N)
                phi(i+1) = phi(1);
            end
           phi_x(i) = (phi(i+1)-phi(i))/dx;
       end
       phi_x = phi_x';
       
       % get f(phi)
       f_phi = 0.25*(phi.^2.0-1.0).^2.0;                % f(\phi)(1:N+1)
       f_phi_tilte = 0.25*( phi_tilte.^2.0-1.0).^2.0;   % f(\phi_tilte)(1:N+1)

       beta = 0.0; % new added.
       
       % get the intergal function l(phi), i.e. functional density
       l = 0.5*kpa*kpa*phi_x.^2.0 + f_phi(1:N) ...
           - beta*0.5*kpa*kpa*phi_tilte_x.^2.0 - beta*f_phi_tilte(1:N); % l(1:N)
       L_phi = (sum(l))*dx;     % energy functional L(\phi), only use left-rectangle formula.
        
        % The following expression will get L increase with time.
%        l = 0.5*kpa*kpa*phi_x.^2.0 - kpa*kpa*phi_tilte_x.^2.0;
%        L_phi = sum(l) + 0.5* (sum(f_phi(2:N+1)) + sum(f_phi(1:N)) ) ...
%         -2.* 0.5 * ( sum(f_phi_tilte(2:N+1)) + sum(f_phi_tilte(1:N)) );
%        L_phi = L_phi * dx;


       
end