function w = minus_Lap_inv_PBC(v,N,dx)

% input: v(1:N+1), N
% output: -Laplace^{-1}v = w

    % row index
    k1(1:2) = [1 2];
    for j = 2:N-2
        k1(4*(j-1)-1:4*(j-1)+2) = [j-1 j j+1 N];
    end
    k1(4*(N-2)-1:4*(N-2)) = [N-2 N-1];
    k1(4*(N-2)+1:4*(N-2)+3) = [1 N-1 N];
    k1 = k1';

    % colum index    
    k2(1:2) = [1 1];
    for j = 2:N-2
        k2(4*(j-1)-1:4*(j-1)+2) = j;
    end
    k2(4*(N-2)-1:4*(N-2)) = [N-1 N-1];
    k2(4*(N-2)+1:4*(N-2)+3) = [N N N];
    k2 = k2';
    
    % nonzero value
    k3(1:2) = [-2 1];
    for j = 2:N-2
        k3(4*(j-1)-1:4*(j-1)+2) = [1 -2 1 -1];
    end
    k3(4*(N-2)-1:4*(N-2)) = [1 -2];
    k3(4*(N-2)+1:4*(N-2)+3) = [1 1 -3];
    k3 = k3';
    
    Coef = sparse(k1,k2,k3);
%     [V,D] = eig(-inv(full(Coef)));
%     min(diag(D))
%     pause
    Rhs = -v*dx*dx;
%     full(Coef);
%     Rhs;
    
    w = Coef\Rhs;
%     figure; plot(w)
%     pause
    
%     % calculate the error
%     err = Coef*w - Rhs;
%     norm_err = norm(err,2);
    
%     err2 = A*w + v;
%     norm_err2 = norm(err2,2);   % This is not 0 sometimes.
%     pause
    
end