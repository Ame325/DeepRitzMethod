
function A = Laplace_1D_Construct(xa,xb,N)
% construct sparse Laplace matrix A

% input: end points: xa and xb, mesh points N+1
% output: Laplace matrix A

dx = (xb-xa)/N;

% kx: colum index
kx(1:3) = [1 2 N]';
for j=2:N-1
    kx(3*(j-1)+1:3*j) = [j-1,j,j+1];
end
kx(3*(N-1)+1:3*N) = [1,N-1,N];
 
% ky: row index
i=1;
for j=1:N
  ky(i:i+2) = j;
  i = i+3;
end
ky = ky';
 
% kz: the nonzero value
kz(1:3) = [-2 1 1]';
for j=2:N-1
    kz(3*(j-1)+1:3*j) = [1 -2 1];
end
kz(3*(N-1)+1:3*N) = [1 1 -2];
 
A = sparse(kx,ky,kz);
% figure; spy(full(A))
% full(A)
% pause
A = A/dx/dx;