function grad_L_H_1 = grad_L_CH_PBC(kpa, A, phi_n_new, phi_n, phi_k, v, w, dx, N)
% The function is to calculate the norm_grad_L by using both new iterative
% point and the old iterative point, simluanteously. Using v*v'*phi, not
% dot(v,phi)*phi
% take variational derivative in H^{-1} metric, but the norm is in L2 metric

% the same as grad_L_CH_NBC_new.m

beta = 0; % new added.
    phi_tilte_n = phi_k + dot(w,phi_n-phi_k)*dx*v;
    phi_n3 = phi_n.^3.;
    grad_L_H_1_vec = -kpa*kpa*A*A*phi_n_new + 2.0*A*phi_n_new ...
        - beta*dot(v,v)*dx*v*dot(w,phi_n_new)*dx + beta*dot(w,phi_k)*dx*dot(v,v)*dx*v ...
        - beta*dot(v,phi_k)*dx*v - 3.*A*phi_n + A*phi_n3 ...
        - beta*kpa*kpa*v*dot(v,A*phi_tilte_n)*dx + beta*v*dot(v,phi_tilte_n.^3.0)*dx;

%     % check 1: right!
%     gradF_L2 = -kpa*kpa*A*phi_k + phi_k.^3 - phi_k;
%     gradF_H1 = kpa*kpa*A*A*phi_k - A*phi_k.^3 + A*phi_k;
%     wf = minus_Lap_inv_PBC(gradF_H1,N,dx);
%     check1 = dot(v,gradF_L2)*dx - dot(v,wf)*dx;
%     
%     % change another expression of grad_L_H1_vec
%     phi_hat =  phi_k + dot(w,phi_n-phi_k)*dx*v;
%     gradF_L2_phihat = -kpa*kpa*A*phi_hat + phi_hat.^3 - phi_hat;
%     grad_L_H_1_vec = gradF_H1 - 2.*dot(v,gradF_L2_phihat)*dx*v;
%     
%      % check 2: right!!!
%     wl = minus_Lap_inv_PBC(grad_L_H_1_vec,N,dx);
%     check2 = dot(grad_L_H_1_vec,wl)*dx - dot(wf,gradF_H1)*dx;
%     
%     % check 3 norm_grad_F_H1, equal to gradF_H_PBC.m, right
%     norm_grad_F_H1 = sqrt(dot(wf,gradF_H1)*dx); % H^{-1} norm
%     pause

%     figure; plot(grad_L_H_1_vec)

% figure; plot(phi_tilte_n); hold on; plot(phi_k,'r')

%     grad_L_H_1 = sqrt(dot(grad_L_H_1_vec,grad_L_H_1_vec)*dx);  % norm in L2
  %  grad_L_H_1 = max(grad_L_H_1_vec);
    
%   % get the norm in H^{-1} metric
  wl = minus_Lap_inv_PBC(grad_L_H_1_vec,N,dx);
  grad_L_H_1 = sqrt(dot(wl,grad_L_H_1_vec)*dx);

%     w = minus_Lap_inv_PBC(grad_L_H_1_vec_check,N,dx);
%    grad_L_H_1 = sqrt(dot(w,grad_L_H_1_vec_check)*dx);
  
  % get the norm in L2 metric
%   grad_L_H_1 = sqrt(dot(grad_L_H_1_vec,grad_L_H_1_vec)*dx);

% grad_L_H_1 = sqrt(dot(grad_L_H_1_vec_check,grad_L_H_1_vec_check)*dx);

end