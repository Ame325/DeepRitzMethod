function w = minus_Lap_inv_PBC_ano(A,v,N)

% input: v(1:N+1), N
% output: -Laplace^{-1}v = w

   A(N+1,1:N) = 1;
   v(N+1) = 0;
   w = -A\v;
%    disp('Using the new minus_Lap_inv method')
%    figure; plot(w)
%    pause
    
end