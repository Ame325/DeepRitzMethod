function [phi_n_new, norm_grad_L] = L_CH_dyna_PBC_new(A, v, w, dt, kpa, phi_n, phi_k, N, dx)
    
    % copied from L_CH_dyna_PBC.m. Difference: add dx in the original
    % scheme
    % Solve the C-H eq. for min L(phi)
    % Input: A=\laplace, v:min-mode
    % Output: phi_n_new(1:N)
    
    % solve pde to get phi_n_new
    phi_tilte = phi_k + dot(w,phi_n-phi_k)*dx*v;
    %phi_tilte = phi_k + v*w'*(phi_n-phi_k);

    beta = 0.0; % new added.
    
    % get the first term in the right hand side
    phi3 = phi_n.^3.;
    phi_tit3 = phi_tilte.^3.0;
    phi_mid = beta* dot(v,phi_tit3)*dx*v;
    
%     f1 = - 3.0*A*phi_n + A*phi3 - 2.*kpa*kpa*dot(v,A*phi_tilte)*v + phi_mid;
    f1 = - 3.0*A*phi_n + A*phi3 - beta*kpa*kpa*v*dot(v,A*phi_tilte)*dx + phi_mid;

    % get the second term in the right hand side
    f2 = beta*dot(w,phi_k)*dx*dot(v,v)*dx*v - beta*dot(v,phi_k)*dx*v;
    
    f = phi_n + dt*f2 + dt*f1;  % RHS
    
    I = eye(N);
    C = beta*dt*dot(v,v)*dx*dx*I;
    Cv = C*v;   % C = 2*dt*I
    
    % B = I + dt*kpa*kpa*A*A - 2*dt*A
     B = I + dt*kpa*kpa*A*A - 2.*dt*A;
    phi_n_new = B\f - dot(w,B\f)/(1+dot(w,B\Cv))*(B\Cv);   % one-time step iteration is finished.
    
    % solve the Ax=f directly
   % B = B+Cv*w';
   % phi_n_new = B\f;
   
%      summa = 0.5*( sum(phi_n_new(1:N-1)) + sum(phi_n_new(2:N)) )*dx;
%     if (summa-m>1.e-2)
%         phi_n_new = phi_n_new/summa*m;
%     end

     grad_L = -kpa*kpa*A*A*phi_n_new + 2*A*phi_n_new - beta*dot(v,v)*dot(w,phi_n_new)*v ...
          + f2 + f1;
      norm_grad_L = sqrt(dot(grad_L,grad_L)*dx);

end