
function v = eigenvector_PBC_fun_new2(A, kpa, dx, phi, N)

% Input: kap, dx, phi(1:N), N
% Output: eigenvector v
% the result is the same as eigenvec.m

%     clear;  %clc;
%     kpa = 0.04; N = 100; dx = 1./N; % phistar;
%     final_phi;
%     phi = density(1:N,9); 

    e = ones(N, 1);
    
    dx2 = dx*dx;
    rkx = kpa*kpa/dx2/dx2;
    
    f = -( 4.*rkx + (3.*phi.^2-1.)/dx2 );
    g = 6.*rkx + 2.*(3.*phi.^2-1.)/dx2;
    
    H = spdiags([rkx*e,f(1:N),g(1:N),f(1:N),rkx*e],[-2,-1,0,1,2],N,N);
    
    H(1,N-1) = rkx;
    H(1,N) = f(N);
    H(2,N) = rkx;
    H(N-1,1) = rkx;
    H(N,1) = f(1);
    H(N,2) = rkx;
%     full(H)
%     pause
     
%     [V,D] = eigs(H,5,'sm');  % sr   % the 13 eigenvalues are ordered from small to big. D(1,1)< D(2,2)< ...< ...
%     fprintf('%18.10f\n',D(1,1))
%     fprintf('%18.10f\n',D(2,2))
%     fprintf('%18.10f\n',D(3,3))
%     fprintf('%18.10f\n',D(4,4))
%     fprintf('%18.10f\n',D(5,5))
%    pause
   
    % get min mode of H by eig. The results are not the same
    [V,d] = eig(full(H));   
    for i = 1:N
        dd(i) = d(i,i);
    end
%     index = find(dd==min(dd));
%     v = V(:,index);
    
    [dum,ind] = sort(dd);
   
    % make order for the first m+1 eigenvalue and the corresponding index
    m = 3;
    for index = 1:m
        for i = 1:m-index+1
            if(dum(index)>dum(index+i))
                t = dum(index+i);
                dum(index+i) = dum(index);
                dum(index) = t;
                tmp = ind(index+i);
                ind(index+i) = ind(index);
                ind(index) = tmp;
            end
        end
    end
    
%     disp('The first five eigenvalues:\n')
%     fprintf('%28.12f',dum(1))
%     fprintf('%28.12f',dum(2))
%     fprintf('%28.12f',dum(3))
%     fprintf('%28.12f',dum(4))
%     fprintf('%28.12f\n',dum(5))
% %     pause
%      % check the integral of the eigenvector corresponds to the smallest
%     % eigenvalue and others be 0 or not! The result is right!!!
%      disp('integral of the eigenvectors:\n')
%     for i =1:5
%        fprintf( '%20.16f\n', sum(V(:,ind(i)))*dx )
%     end
%     pause
    
    % calculate the integral of the eigenvector from smaller to larger one
    % and choose the first eigenvector whose integral is 0 as our min-mode
    
    phi(N+1) = phi(1);
    phix = (phi(2:N+1)-phi(1:N))/dx;
    phix = phix / sqrt(dot(phix,phix));
%     force = gradF_H_PBC(A,phi(1:N),kpa,dx,N);     % in H^{-1} metric

%     figure; plot(V(:,ind(2))); hold on; plot(phix,'r')
%     pause

%     figure; plot(V(:,ind(1)),'g'); hold on; plot(V(:,ind(2)),'r'); hold on; plot(V(:,ind(3)),'k')
    i = 1;
    v = V(:,ind(i));
    cosx = dot(v,phix)/sqrt(dot(v,v))/sqrt(dot(phix,phix));
    if abs(cosx)>0.95 %& force<0.01*f0
        for j = i:N-1
            V(:,ind(j)) = V(:,ind(j+1));
        end
%         disp('The first one is degenerate direction and is passed!')
%         pause
    else
        i = i+1;
        v = V(:,ind(i));
        cosx = dot(v,phix)/sqrt(dot(v,v))/sqrt(dot(phix,phix));
        if abs(cosx)>0.95 %& force<0.01*f0
            for j = i:N-1
                V(:,ind(j)) = V(:,ind(j+1));
            end
%         disp('The second one is degenerate direction and is passed!')
%         pause
        end
    end
%     figure; plot(V(:,ind(1)),'g'); hold on; plot(V(:,ind(2)),'r'); hold on; plot(V(:,ind(3)),'k')
%     pause

    index = 1;
    v = V(:,ind(index));
    int_v = sum(v(:))*dx;  %sum(V(:,ind(index)))*dx; %( sum(v(2:N)) + 0.5*v(1) + 0.5*v(N+1) ) *dx
    while abs(int_v) > 1.e-6
%         disp('go into while')
%         pause
        index = index + 1;
        v = V(:,ind(index));
        int_v = sum(v(:))*dx;
%         fprintf( '%20.16f\n', int_v)
    end
%     index
%     pause
    
%     if(index == 2)
%         disp('index attains 2!')
%         index
%         phi(N+1) = phi(1);
%         phix = (phi(2:N+1)-phi(1:N))/dx;
%         phix = phix / sqrt(dot(phix,phix)); % degenerater direction by expression
%         figure; plot(V(:,ind(2))); hold on; plot(phix,'r')
%         cosx = dot(V(:,ind(2)),phix)/sqrt(dot(V(:,ind(2)),V(:,ind(2))))/sqrt(dot(phix,phix))
%         pause
%     end
%     index
%     pause
   
   
 
%     fprintf('%21.16f',dum(1))
%     fprintf('%21.16f',dum(2))
%     fprintf('%18.10f\n',dum(3))
%     fprintf('%18.10f',dum(4))
%     fprintf('%18.10f',dum(5))
%     V(:,ind(2))
%     figure; plot(real(V(:,ind(2))))
%     pause
%     fprintf('%18.10f\n',dum(6))
%     fprintf('%18.10f\n',dum(7))
%     fprintf('%18.10f\n',dum(8))
%     fprintf('%18.10f\n',dum(9))
%     fprintf('%18.10f\n',dum(10))
%     fprintf('%18.10f\n',dum(11))
%     fprintf('%18.10f\n',dum(12))
%     dum(1)< dum(3)

% check the integral of the eigenvector corresponds to the smallest
% eigenvalue and others be 0 or not! The result is right!!!
% for i =1:N
%    fprintf( '%10.6f\n', sum(V(:,ind(i))) )
% end

% check the degeneration direction is parallel to u_c': v1//ux
% figure; plot(V(:,ind(1)),'b')   % degenerate direction of H_tilte
% hold on; 
% plot(V(:,ind(2)),'k')   % tangent direction
%  hold on;
%  phi(N+1) = phi(1);
% phix = (phi(2:N+1)-phi(1:N))/dx;
% phix = phix / sqrt(dot(phix,phix)); % degenerater direction by expression
% plot(phix,'r')
% cosx = dot(V(:,ind(1)),phix)/sqrt(dot(V(:,ind(1)),V(:,ind(1))))/sqrt(dot(phix,phix))
% pause
% % shall not compare with ind(2) here, shall be changed to the ind(2) in
% % eigenvec.m
%     pause  
%     v = V(:,ind(index));
%     v = V(:,ind(1));   % the min-mode
%     v = V(:,3);
    
     w1 = minus_Lap_inv_PBC(v,N,dx);
     norm_v = sqrt(dot(w1,v)*dx);
%     norm_v_square = dot(w1,v)
     v = v/norm_v;
%      figure; plot(v)
     
%      % check the norm of v is 1.
%      w1 = minus_Lap_inv_PBC(v,N,dx);
%      norm_v = sqrt(dot(w1,v)*dx)
     
%      v = v/norm(v);
     
end
     
