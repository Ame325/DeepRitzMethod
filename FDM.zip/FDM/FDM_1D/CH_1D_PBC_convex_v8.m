%% Convex splitting min E---> C-H PBC % final version, 1D case
% This code contains the Laplace operator in 1D case.
% copied from IMF_CH_PBC_convex_v8.m
% used to get the steady state of CH equation
% Take alpha = 0, beta = 0. The IMF becomes CH.
%% This code is to implement that: 
% 1. calculate L(\phi) and |\gradient L(phi)| at each iteration;
% 2. calculate |\gradient F(\phi)| at each circle;
% 3. In \phi^{k+1} = argmin L(\phi;\phi^k,alpha, beta), modify \phi^k at
% each iteration.
% Only consider the first N mesh points in [0,1] because of the PBC;
% NOTE: Have checked that: N can be 100 or 1000, the iteration # almost the
% same. good news!

% We need modify the module about: (1) the PDE solving \partial_t phi =
% -\frac{\delta L}{\delta\phi}.  (2) The force, i.e., the RHS of the above
% PDE. (3) The calculation of L in each inner iteration.

% Results: IMF CH eq. PBC can achieve quadratic convergence rate.
% The results are very good!!!

% copied from IMF_CH_PBC_convex_v7.m
% The key difference is the sub-function: minus_Lap_inv_PBC.m
% Here, we adapt a more easier method to solve w = -Laplace^{-1}v
% The results are the same, very good!


% clc;
clear;
kpa = 0.04;
N = 100;   % or 100, the convergence rate are the same.
dt = 0.01;
dx = 1.0/N;
tol = 1.e-8; % 1.e-5; %2.2e-6;  % 6.0e-7;  % 5.0e-7 for N=1000;  % 5.e-8 for N=100
norm_err = 1.e-6; %8.e-6;
x = linspace(0,1,N+1);
x = x';
V = 1.0;

%beta = 2.0;

iter_N = 50;

% A = \lapace
A = Laplace_1D_Construct(0,1,N);
 
% Read phi_k(1:N)
final_phi; % N=100;
%final_phi_1000;

% phi0 = cos(2*pi*x);   % Not converge under this initial, or sin(2*pi*x)
% phi0 = phi0 + 0.6;

% take phi0 = density(:,14) for outer comparison
  phi0 = density(:,14);      % initialization of phi_k  (:,9) or (:,17) is the saddle. % used for whole efficiency comparison.
% verify Liuyi's result
% load dim1_epoch_500.mat
% data = data';
% phi0 = data(1:N+1,500);

% % Next try to interpolate from N=100 to N=1000. and then check the new force.
% newx = linspace(0,1,1000);
% newphi = interp1(x,data(:,end),newx);
% newphi = newphi';
% force = gradF_H_PBC(A,newphi,kpa,dx,N);  %4.48*100, still large.

%%%%% stop here! only used to check the force!

% initial force
error = gradF_H_PBC(A,phi0(1:N),kpa,dx,N);  % 2.8189

% calculate the initial mass
init_mass = (sum(phi0(2:N))+0.5*(phi0(1)+phi0(N+1)))*dx;

% ensure initial mass is 0.6
m = 0.6;
phi0 = phi0 + m/V - init_mass/V;

phi_k = phi0(1:N);

% % get free energy
% FE = 0.0;
% for i=2:N
%     FE = FE + 0.5* kpa*kpa/dx/dx* (phi_k(i) - phi_k(i-1))^2 + 0.25*(phi_k(i)^2-1.)^2;
% end
% FE = FE + 0.5* kpa*kpa/dx/dx* (phi_k(1) - phi_k(N))^2 + 0.25*(phi_k(1)^2-1.)^2;
% FE = FE*dx;
% disp(FE)
% fprintf(' %18.12f \n ',FE)
% pause
 
% h = figure;plot(x,phi0,'k--','LineWidth',2),xlabel('x'), ylabel('\phi(x)');
h = figure;plot(x(1:N+1),phi0,'k--','LineWidth',2),xlabel('$x$','interpreter','latex'), ylabel('$\phi(x)$','interpreter','latex');
hold on;
% set(gca,'FontSize',14)
% set(get(gca,'xlabel'),'FontSize',15), set(get(gca,'ylabel'),'FontSize',14)
% set(get(gca,'title'),'FontSize',14)
% pause

% Calculate force, i.e., gradient F(phi^k)
% norm_grad_F_L2(1) = gradF_L(A,phi_k,kpa,dx);     % in L^2 metric
norm_grad_F_H(1) = gradF_H_PBC(A,phi_k,kpa,dx,N);     % in H^{-1} metric

% NOTE: two sides shall be considered: graident of F shall be taken in
% H^{-1} metric; The H^{-1} norm shall also be taken in H^{-1} metric.
% But the method sqrt(dot(-A*grad_F,-A*grad_F)*dx) only considers the the
% first one, not the second one.

% output colum headings
fprintf( '   k  | norm_neighboring | norm_grad_F in H^{-1} | norm_grad_F in L2  \n')
i = 0;
fprintf( '%4i  | ',i+1)
% fprintf(' %18.12f ',norm_grad_F_L2(1) )
fprintf(' %18.12f \n ',norm_grad_F_H(1) )
% pause

% rotation step
% v = eigenvec(kpa, dx, N, phi_k, A);   % CH NBC/PBC  % original, also right
% v = eigenvector_PBC_fun(kpa,dx,phi_k,N);   % new
%    v = eigenvector_PBC_fun_new(kpa,dx,phi_k,N);
v = eigenvector_PBC_fun_new2(A,kpa,dx,phi_k,N);
% v = eigenvector_PBC_fun_new1(A, kpa,dx,phi_k,N, norm_grad_F_H(1));
% v = eigenvec_NBC(kpa, dx, N, phi_k);    % AC NBC
% figure; plot(v);
% pause

w = minus_Lap_inv_PBC_ano(A,v,N);
% w = minus_Lap_inv_PBC(v,N,dx);


% Normallization
phi_n = phi_k;
% summa = ( sum(phi_n(1:N))+phi_n(N) )*dx;
% if (summa-0.6>1.e-2)
%     phi_n = phi_n/summa*0.6;
% end

phi(1:N,1) = phi_k;

mass(1) = init_mass;

tot_num = 0;
% for i=1:1
% while norm_grad_F_H(i+1) > tol

% err(1) = 1.0;
% fprintf(' %18.12f \n ',err(i+1))
% while err(i+1) > tol
while norm_grad_F_H(i+1) > tol
% for k = 1: 1200

    i = i+1;            % Outer iteration #  
    t(1) = 0;
    norm_grad_L(1) = grad_L_CH_PBC(kpa, A, phi_n, phi_n, phi_k, v, w, dx, N); % in L^2 metric
%     fprintf('%18.12f', norm_grad_L(1))
%     pause
    L(1) = L_CH_PBC(phi_n, phi_k, v, w, kpa, dx, N);          % check L(t) decrease with t(iteration #)
    
    for j=1:iter_N  % 10(33 circles)   20(15)  50(10)  100(19)  500(error)    
        
%     j = 0;
%     while norm_grad_L(j+1) > norm_err
% %     norm_dist(1) = 1.;
% %     while norm_dist(j+1) > norm_err
%         j = j + 1;

        t(j+1) = t(j) + dt;
        tot_num = tot_num + 1;
        % convex scheme
        [phi_n_new, norm_grad_L1(j+1)] = L_CH_dyna_PBC_new(A, v, w, dt, kpa, phi_n, phi_k, N,dx);

        L(j+1) = L_CH_PBC(phi_n_new, phi_k, v, w, kpa, dx, N);          % check L(t) decrease with t(iteration #)
    
% %      norm_grad_L(j+1) = grad_L_CH_PBC(kpa, A, phi_n_new, phi_n, phi_k, v, w, dx, N); % using phi^{n+1} and phi^n at the same time.
          norm_grad_L(j+1) = grad_L_CH_PBC(kpa, A, phi_n_new, phi_n_new, phi_k, v, w, dx, N); % Only using phi^{n+1}.in H^{-1} or L2 metric
           diff = phi_n-phi_n_new;
           w_diff = minus_Lap_inv_PBC_ano(A,diff,N);
           norm_dist(j) = sqrt(dot(w_diff,diff)*dx);    % H^{-1} norm
            
          phi_n = phi_n_new;                                % modify phi^n

   end

    %saveas(h1,'','fig')
%     saveas(h2,'norm_dist','fig')
%     saveas(h3,'L_t','fig')
%     saveas(h4,'final_state','fig')
%     pause
% j

    phi_k = phi_n;   % in this case, phi_k will only modify in each rotation step

      % new added
    mass1 = (sum(phi_k(2:N))+0.5*(phi_k(1)+phi_k(1)))*dx;
    phi_k = phi_k + m/V - mass1/V;
    mass(i+1) = (sum(phi_k(2:N))+0.5*(phi_k(1)+phi_k(1)))*dx;
    
    % save phi_k at each circle to a new variable
    phi(1:N,i+1) = phi_k;
    
%     v = eigenvec(kpa, dx, N, phi_k, A);         % original
%     v = eigenvector_PBC_fun(kpa,dx,phi_k,N);   % new
%    v = eigenvector_PBC_fun_new(kpa,dx,phi_k,N);
   v = eigenvector_PBC_fun_new2(A,kpa,dx,phi_k,N);
%     v = eigenvector_PBC_fun_new1(A, kpa,dx,phi_k,N,norm_grad_F_H(1));
%     w = minus_Lap_inv_PBC(v,N,dx);
    w = minus_Lap_inv_PBC_ano(A,v,N);
   % norm_grad_F_L2(i+1) = gradF_L(A,phi_k,kpa,dx);     % in L^2 metric
    norm_grad_F_H(i+1) = gradF_H_PBC(A,phi_k,kpa,dx,N);     % in H^{-1} metric

            
    fprintf( '%3i  | ',i+1)
%     fprintf(' %18.12f \n ',err(i+1))
    fprintf(' %18.12f | %18.12f \n ',norm_grad_F_H(i+1), mass(i+1))
%     fprintf(' %18.12f \n ',norm_err(i+1))
%     hold on;
%     plot(x(1:N),phi_k)
%     pause
%      hold on; plot(x(1:N),phi_k)
end

phi_final = phi_k;      % phi_final(1:N)
phi_k(N+1) = phi_k(1);  % phi_k(1:N+1)

% get free energy
FE = 0.0;
for i=2:N+1
    FE = FE + 0.5* kpa*kpa/dx/dx* (phi_k(i) - phi_k(i-1))^2 + 0.25*(phi_k(i)^2-1.)^2;
end
FE = FE*dx;
disp(FE)
fprintf(' %18.12f \n ',FE)

plot(x,phi_k,'LineWidth',2);
hold on; plot(x,density(1:N+1,end),'b')
legend('initial state \phi^{(0)}','final state','Exact state')
%legend('initial state \phi^{(0)}','final state')
set(gca,'FontSize',20)
set(get(gca,'xlabel'),'FontSize',26), set(get(gca,'ylabel'),'FontSize',26)
set(get(gca,'title'),'FontSize',14)

%saveas(h,'saddle_IMF','fig')

size_phi = size(phi);
%n_size = size(norm_grad_F);
% tot_num = iter_N * size_phi(2);
x_axis = linspace(1,tot_num,size_phi(2));
y_axis = linspace(1,size_phi(2),size_phi(2));

% write data to file x_axis and norm_err

% figure; semilogy(x_axis,norm_grad_F_H,'LineWidth',3),xlabel('total iteration #','interpreter','Tex'), ...
%     ylabel('$\|\Delta\delta_\phi F(\phi^{(k)})\|_{H^{-1}}$','interpreter','latex')
%     title('convex result')
% set(gca,'FontSize',20)
% % set(gca,'title',16)
% set(get(gca,'xlabel'),'FontSize',26), set(get(gca,'ylabel'),'FontSize',26)
% 
% figure; semilogy(y_axis,norm_grad_F_H,'LineWidth',2),xlabel('outer cycle #','interpreter','Tex'), ...
%     %ylabel('$\|\nabla F(\phi^{(k)})\|_{L^2}$','interpreter','latex')
%     ylabel('$\|\delta_\phi F(\phi^{(k)})_{H^{-1}}\|_{H^{-1}}$','interpreter','latex')
%     title('convex result')
% set(gca,'FontSize',16)
% % set(gca,'title',16)
% set(get(gca,'xlabel'),'FontSize',16), set(get(gca,'ylabel'),'FontSize',20)

% calculate norm_err at each circle.
% save the difference between phi_star and each phi_k
for i = 1:size_phi(2)
    err_phik_phistar = phi(1:N,i) - phi_final; % phi_k=phi(1:N+1,N_size+1), get |u_k-u*|_L2
%    err_phik_phistar = A*err_phik_phistar; % get |-\Delta(u_k-u*)|_L2  %
%    This is wrong!!!
    norm_err_phik_phistar(i) = sqrt(dot(err_phik_phistar,err_phik_phistar)*dx); % get L2 norm error
%     norm_err_phik_phistar(i) = sqrt(dot(-A\err_phik_phistar,err_phik_phistar)*dx); % get H^{-1} norm error
%     fprintf('%18.12f\n',norm_err_phik_phistar(i));
end


% figure; plot(x_axis,norm_err_phik_phistar,'LineWidth',2),xlabel('total iteration #','interpreter','Tex'), ...
%     %ylabel('$\|\phi^{(k)}-\phi^*\|_{L^2}$','interpreter','latex')
% ylabel('$\|\phi^{(k)}-\phi^*\|_{H^{-1}}$','interpreter','latex')
% title('convex result')
% set(gca,'FontSize',16)
% % set(gca,'title',16)
% set(get(gca,'xlabel'),'FontSize',16), set(get(gca,'ylabel'),'FontSize',20)

%  save('result_convex_N1000');
tot_num

phix = ( phi_k(2:N+1) - phi_k(1:N) ) /dx;
% figure; plot(x(1:N),phix,'r')