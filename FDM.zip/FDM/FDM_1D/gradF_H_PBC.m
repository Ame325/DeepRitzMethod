% calculate force \| \nabla F(phi) \|_{H^{-1}}
function norm_grad_F = gradF_H_PBC(A,phi,kpa,dx,N)
% function norm_F = gradF(A,phi,kpa,dx,N)
% The newest way to calculate the norm of gradient of F

    fprime = phi.^3. - phi;
    gradF_L2 = -kpa*kpa*A*phi + fprime;     % grad F in L2 metric

    % norm_test = sqrt(dot(gradF_L2,gradF_L2)*dx);
    % norm_grad_F = norm_test;

    gradF_H1 = -A*gradF_L2;                 % grad F in H_^{-1} metric
    
%     figure; plot(gradF_H1)
    
%     [V,D] = eig(full(-A));
%     for i = 1:201
%         e1 = -A*V(:,i);
%         e2 = D(i,i)*V(:,i);
%         err = e1 - e2;
%         max(err)
%         min(err)    
%     end
%     max(diag(D))
%     min(diag(D))

%   Do NOT use the simplified expression to calculate H^{-1} norm!!!
%    norm_grad_F = sqrt(dot(gradF_L2,-A*gradF_L2)*dx);    % H^{-1}norm
%    norm_square1 = dot(gradF_L2,-A*gradF_L2)  % negative. why??? Because
%    here shall be "dot(gradF_L2,A*gradF_L2)".
%   % Because they are not equal!
%     pause

%     norm_grad_F = sqrt(dot(gradF_H1,gradF_H1)*dx);       % L2 norm
    
    w = minus_Lap_inv_PBC(gradF_H1,N,dx);   % -inv_Laplace gradF_H^{-1}

    norm_grad_F = sqrt(dot(w,gradF_H1)*dx); % H^{-1} norm
    
%     norm_square2 = dot(w,gradF_H1)   % used to check negative or positive
%     err = A*w + gradF_H1;
%     norm_err = norm(err,2)  % used to check -inv Laplace gradF_H1 is right
%     pause

end

